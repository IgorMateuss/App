import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: 'App',
    //configurar a aparência de todo o aplicativo
    theme: ThemeData(
      primarySwatch: Colors.blueGrey,
    ),
    home: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tela 1"),
      ),
      body: ListView(
        children: [
          Container(
            child:Image.asset(
              "imagens/mulher.jpg",
              fit: BoxFit.cover,
            ),
          ),
          Container(
              alignment:Alignment.center,
              padding: EdgeInsets.fromLTRB(10, 20, 10, 0),
              child: (
                  Text('Olá, sou Anabelle',style: TextStyle(color:Colors.blue, fontSize:30))
              )),
          Container(
              alignment:Alignment.center,
              padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
              child: (
                  Text('sua assistente virtual',style: TextStyle(color:Colors.red, fontSize:30))
              )),
          Container(
            padding: EdgeInsets.fromLTRB(10, 30, 10, 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Image.asset(
                  "imagens/formato.png",
                  fit: BoxFit.cover,
                ),
                Image.asset(
                  "imagens/email.png",
                  fit: BoxFit.cover,
                ),
                Image.asset(
                  "imagens/bate-papo.png",
                  fit: BoxFit.cover,
                ),
              ],
            )
          ),

          Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => App()));
                },
                icon: Icon(Icons.arrow_right),
                label: Text('Acessar App Assistente Virtual'),
              ))
        ],
      ),
    );
  }
}

class App extends StatelessWidget {
  const App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tela 2'),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.map),
            title: Text('Mapa'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => MyMap()));
            },
          ),
          ListTile(
            leading: Icon(Icons.image),
            title: Text('Albúm'),
          ),
          ListTile(
            leading: Icon(Icons.phone),
            title: Text('Fone'),
          ),
          ListTile(
            leading: Icon(Icons.accessible),
            title: Text('Acessibilidade'),
          ),
          ListTile(
            leading: Icon(Icons.location_pin),
            title: Text('Localização'),
          ),

          ElevatedButton(
            onPressed: () {},
            child: Text('Pesquisar Tópicos'),
          ),
          Image.asset(
            "imagens/pesquisa.jpg",
            fit: BoxFit.cover,
          ),
          Padding(padding: EdgeInsets.all(32)),
          Center(
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text('Volte ao Início'),
            ),
          ),
        ],
      ),
    );
  }
}

class MyMap extends StatelessWidget {
  const MyMap({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tela 3'),
      ),
      body: ListView(
        children: [
          Container(
            alignment:Alignment.center,
            padding: EdgeInsets.fromLTRB(10, 20, 10, 10),
            child: Text(
              'Mapa',
              style: TextStyle(color:Colors.black87, fontSize:40),
            ),
          ),
          Image.asset("imagens/map.jpg",
            fit: BoxFit.cover,
          ),
          Container(
              alignment:Alignment.center,
              padding: EdgeInsets.fromLTRB(10, 20, 10, 0),
              child: (
                  Text('Suas localizações',style: TextStyle(color:Colors.black87, fontSize:30))
              )),
          Container(
              padding: EdgeInsets.fromLTRB(10, 30, 10, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Image.asset(
                    "imagens/icon_globo.png",
                    fit: BoxFit.cover,
                  ),
                  Image.asset(
                    "imagens/icon_map.png",
                    fit: BoxFit.cover,
                  ),
                  Image.asset(
                    "imagens/icon_papel.png",
                    fit: BoxFit.cover,
                  ),
                ],
              )
          ),

          Padding(padding: EdgeInsets.all(40)),
          Center(
            child: ElevatedButton.icon(
              onPressed: (){
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text("Voltar"),
            ),
          ),
        ],
      ),
    );
  }
}
